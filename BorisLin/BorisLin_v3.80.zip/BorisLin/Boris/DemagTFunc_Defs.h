#pragma once

//default number of images to use for pbc calculations
#define PBC_X_IMAGES	10
#define PBC_Y_IMAGES	10
#define PBC_Z_IMAGES	10

//-1 to disable
#define ASYMPTOTIC_DISTANCE 40
