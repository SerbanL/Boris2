#include "stdafx.h"
#include "HeatBaseCUDA.h"

#if COMPILECUDA == 1

#ifdef MODULE_COMPILATION_HEAT


#endif

#endif