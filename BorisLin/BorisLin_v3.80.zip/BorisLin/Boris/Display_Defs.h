#pragma once

//default text font size
#define FONT	"Consolas"		//nice monospaced font (default for Visual Studio)
#define TEXTSIZE 15
#define MESHTEXTSIZE	30

//number of pixels to shift the hover info text box away from mouse position (so the mouse is inside the window when created)
#define HOVERINFOTEXTBOX_MOUSESHIFT 1