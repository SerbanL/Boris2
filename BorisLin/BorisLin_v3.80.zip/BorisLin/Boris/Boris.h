#pragma once

#include "resource.h"
#include "Simulation.h"
#include "BorisLib.h"
#include "cuBLib_Flags.h"
#include "Commands.h"

////////////////////////////////////
//Program master object

static Simulation *pSim = nullptr;

